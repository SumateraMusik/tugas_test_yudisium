<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Detail Koneksi InfinityFree 
$host = "sql107.infinityfree.com"; 
$user = "if0_40643505"; 
$pass = "Z5Hm4zxgdB8SWL"; 
$db   = "if0_40643505_tugas_test"; 

try {
    $conn = new mysqli($host, $user, $pass, $db);
    $conn->set_charset("utf8mb4");
    // Koneksi aman dan siap digunakan 
} catch (mysqli_sql_exception $e) {
    // Menampilkan pesan error jika koneksi gagal 
    die("Koneksi Database Gagal: " . $e->getMessage());
}
?>